# Changelog

## Alpha 1.2 — Beta Readiness
- Added deterministic campaign event adapter with unique event-ID deduplication.
- Added explicit rejection codes for invalid, out-of-order, and unauthorized progression events.
- Added trigger contract JSON to guide the Galaxy runtime port.
- Added adapter-level end-to-end tests and explicit Beta exit criteria.
- Preserved original terrain/object binaries and survival logic.
- No claim of Galaxy integration or in-game validation; those remain release gates.

## Alpha 1.1
- Campaign progression reference state machine, campaign save/load, region inventory, and source validation.

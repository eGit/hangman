# Alpha 1.0 — Narrative Systems Prototype

## What changed in this release

This release adds concrete source-level content for the narrative loop and executable reference logic for its state transitions.

### Map source change
`Dantes_Inferno.SC2Map/Regions` now has 12 additional rectangular subregions (IDs 269–280):
- `Inferno_Dante_Secret`
- `Inferno_VERSE_01_Limbo` through `Inferno_VERSE_09_Frozen_Heart`
- `Inferno_Divine_Comedy_Artifact`
- `Inferno_Three_Faced_King_Arena`

The existing 268 region entries were retained. The 12 additions provide stable world-space anchor volumes, not placed props or active triggers. Their coordinates are a first pass derived from the Alpha 0.8 region layout and MUST be checked against the terrain in Galaxy Editor before runtime use.

### Narrative content
`systems/narrative_manifest.json` contains stable IDs, circle associations, first-pass anchor rectangles, unique original verse text, discovery cues, repeatability rules, and unlock rules for all requested narrative features.

### Executable state logic
`systems/inferno_state.py` implements a testable reference state machine:
- Gate discovery and hidden Dante encounter are once-per-run and idempotent.
- Each of the nine verse IDs can be collected once; unknown IDs are rejected.
- The artifact is locked until all nine verses are collected and can only be claimed once.
- The Three-Faced King is locked until artifact acquisition; active encounters cannot be double-started; victory is terminal for that run; failure permits retry.
- Narrative completion is tracked separately from survival wave progression.

`tests/test_inferno_state.py` exercises these contracts.

## Critical limitation — not yet game-integrated

The supplied loose map source has no inspectable `Triggers`, `TriggerLibs`, `MapScript.galaxy`, or equivalent gameplay script. The environment also has no verified Galaxy Editor or compatible map-packing tool. Consequently, this release does NOT claim that these Python state transitions are called by StarCraft II, that the new regions are correctly placed in the rendered terrain, or that a packed `.SC2Map` runs.

The next integration task is to recover/open the real gameplay base with its original triggers and dependencies, then port these state contracts into that existing trigger framework. Do not invent trigger file formats or replace the original survival triggers.

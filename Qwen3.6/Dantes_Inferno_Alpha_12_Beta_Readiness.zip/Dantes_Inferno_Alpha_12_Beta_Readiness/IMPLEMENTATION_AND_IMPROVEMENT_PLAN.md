# Alpha 1.1 → Release Candidate: Implementation and Improvement Plan

## Alpha 1.1 — integrate the real trigger framework (blocking)
1. Recover the actual Kerrigan Survival gameplay map, original trigger files, object data, dependency set, and map metadata. Compare against the supplied 22 reference maps; do not assume the terrain prototype is the gameplay base.
2. Establish a supported open/save/build pipeline and produce a clean unchanged test map.
3. Port the state contracts from `systems/inferno_state.py` into the base map's verified trigger system. Preserve the original wave triggers; new narrative triggers must be isolated and named.
4. Replace logical anchor rectangles with editor-verified coordinates. Add one supported, verified world object per feature before implementing interactions.
5. Run in-editor smoke tests for Gate, Dante, verse collection, artifact unlock, and King lifecycle.

**Exit gate:** a packed test map opens in Galaxy Editor; each interaction fires in-game; original survival still starts and progresses.

## Alpha 1.2 — playable vertical slice
1. Complete the spawn → Gate of No Return → Dark Wood → Limbo route.
2. Add supported asset placements and real terrain/material edits using the editor or a verified source serializer.
3. Add the Gate clue, Dante secret, and `VERSE_01` in world space, with readable interaction feedback.
4. Test Kerrigan movement, enemy routing, camera/sightlines, collision, and survival wave flow on the slice.
5. Regenerate minimap from the actual transformed map.

**Exit gate:** repeatable playthrough from spawn through Limbo with no survival regression.

## Alpha 1.3 — nine-circle terrain pass
Implement each biome with actual terrain, material, height/cliff, scenery, and landmark changes. Proposed identity:
- Dark Wood: twisted vegetation, broken ruins, route silhouettes.
- Limbo: pale stone and broad sightlines.
- Tempest: storm-worn rock and broken-bridge silhouettes.
- Devouring Pit: sunken basin and safe ramps.
- Treasury of Ash: ruined vaults and ash motifs.
- Black River: dark river-like corridor and verified crossings.
- Burning Necropolis: dense ruined skyline and fire-lit landmarks.
- River of Blood: crimson visual language and clear combat banks.
- Tenfold Labyrinth: branching but legible corridors with navigation clues.
- Frozen Heart: ice silhouettes, cold palette, final arena approach.

Every pass requires before/after evidence, pathing review, and a rollback snapshot. Decorative assets must not block the survival route unless intentionally designed and tested.

**Exit gate:** all nine regions have visibly distinct, editor-verified terrain and gameplay-safe routes.

## Alpha 1.4 — complete narrative and boss encounter
1. Implement `VERSE_01`–`VERSE_09` with once-per-run collection, duplicate prevention, feedback, and progress display.
2. Add optional introductory clue separate from the nine-verse counter.
3. Implement Dante's hidden discovery with repeatable safe feedback and no control hijack.
4. Implement artifact unlock at nine verses; test early attempts and duplicate interactions.
5. Implement Three-Faced King using verified units/abilities and the map's existing trigger conventions. Define phases, damage windows, victory, failure, retry, and cleanup.
6. Verify survival waves continue correctly before, during, and after optional content.

**Exit gate:** all narrative paths and boss state transitions tested in-game.

## Alpha 1.5 — release candidate
- Full clean build, dependency audit, metadata and map branding.
- Test all route transitions, wave progression, restarts, all collectibles, artifact gate, boss victory/failure/retry, and multiplayer if supported.
- Test minimum and maximum supported game settings; inspect pathing and performance under heavy waves.
- Rebuild from clean source and verify the final `.SC2Map` in Galaxy Editor and in-game.
- Deliver packed map, editable source, hashes, file-level change log, test evidence, and known limitations.

## Improvement backlog (after baseline works)
- Add a subtle diegetic cue per verse rather than relying only on UI text.
- Add a nine-segment collection indicator that does not obscure combat.
- Use optional shortcuts as rewards for exploration, never as mandatory progression gates unless pathing is proven.
- Make biome transitions readable through lighting, silhouettes, materials, and sound/effect assets supported by dependencies.
- Add a boss intro only if the existing trigger/cinematic framework supports it; otherwise use a safe in-world reveal.
- Add localization-ready text keys rather than hard-coded strings once the trigger pipeline is known.
- Add performance budgets for doodad density and effects.
- Track every improvement with a measurable acceptance test and a rollback commit.

## Non-negotiable release gates
- No guessed binary terrain serialization.
- No invented asset IDs or dependency identifiers.
- No claim of editor/game validation without recorded tests.
- No overwrite of original survival triggers without a baseline comparison.
- A feature is complete only when source implementation, engine integration, and its acceptance test all pass.

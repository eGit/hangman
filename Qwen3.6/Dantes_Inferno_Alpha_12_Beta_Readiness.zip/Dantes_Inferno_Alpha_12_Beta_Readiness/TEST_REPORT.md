# Alpha 1.2 test report

```text
test_cannot_clear_without_verse (test_inferno_campaign.CampaignTests.test_cannot_clear_without_verse) ... ok
test_checkpoint_and_retry (test_inferno_campaign.CampaignTests.test_checkpoint_and_retry) ... ok
test_circle_gates_enforced (test_inferno_campaign.CampaignTests.test_circle_gates_enforced) ... ok
test_circle_manifest_has_nine_unique_verses (test_inferno_campaign.CampaignTests.test_circle_manifest_has_nine_unique_verses) ... ok
test_corrupt_save_invariant_rejected (test_inferno_campaign.CampaignTests.test_corrupt_save_invariant_rejected) ... ok
test_save_load_round_trip (test_inferno_campaign.CampaignTests.test_save_load_round_trip) ... ok
test_sequential_full_campaign (test_inferno_campaign.CampaignTests.test_sequential_full_campaign) ... ok
test_wrong_active_circle_cannot_clear (test_inferno_campaign.CampaignTests.test_wrong_active_circle_cannot_clear) ... ok
test_artifact_locked_until_all_circles_cleared (test_inferno_runtime.RuntimeAdapterTests.test_artifact_locked_until_all_circles_cleared) ... ok
test_event_id_deduplication (test_inferno_runtime.RuntimeAdapterTests.test_event_id_deduplication) ... ok
test_failure_retry_then_victory (test_inferno_runtime.RuntimeAdapterTests.test_failure_retry_then_victory) ... ok
test_full_campaign_victory (test_inferno_runtime.RuntimeAdapterTests.test_full_campaign_victory) ... ok
test_gate_precedes_dante (test_inferno_runtime.RuntimeAdapterTests.test_gate_precedes_dante) ... ok
test_invalid_outcome_rejected (test_inferno_runtime.RuntimeAdapterTests.test_invalid_outcome_rejected) ... ok
test_unknown_event_rejected_without_consuming_id (test_inferno_runtime.RuntimeAdapterTests.test_unknown_event_rejected_without_consuming_id) ... ok
test_verse_requires_active_circle (test_inferno_runtime.RuntimeAdapterTests.test_verse_requires_active_circle) ... ok
test_all_nine_verses_unique_and_duplicates_do_not_increment (test_inferno_state.InfernoStateTests.test_all_nine_verses_unique_and_duplicates_do_not_increment) ... ok
test_artifact_requires_all_nine_verses (test_inferno_state.InfernoStateTests.test_artifact_requires_all_nine_verses) ... ok
test_boss_failure_can_retry (test_inferno_state.InfernoStateTests.test_boss_failure_can_retry) ... ok
test_boss_unlock_start_victory (test_inferno_state.InfernoStateTests.test_boss_unlock_start_victory) ... ok
test_cannot_resolve_inactive_boss (test_inferno_state.InfernoStateTests.test_cannot_resolve_inactive_boss) ... ok
test_gate_and_dante_are_idempotent (test_inferno_state.InfernoStateTests.test_gate_and_dante_are_idempotent) ... ok
test_narrative_completion_does_not_claim_survival_progression (test_inferno_state.InfernoStateTests.test_narrative_completion_does_not_claim_survival_progression) ... ok

----------------------------------------------------------------------
Ran 23 tests in 0.002s

OK
```

Static Python tests validate the reference campaign and runtime adapter only; they are not Galaxy Editor or in-game tests.

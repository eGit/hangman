# Milestone 1.0 — Narrative Systems Prototype

## Objective
Move from a documentation-only readiness package to source changes and testable feature logic without pretending that unverified runtime integration is complete.

## Source changes
1. Added 12 logical subregions (IDs 269–280) to the map's `Regions` XML.
2. Added a complete manifest for Gate of No Return, hidden Dante, nine Lost Verses, Divine Comedy artifact, and Three-Faced King.
3. Added unique original text for each Lost Verse and short interaction payoffs.
4. Implemented a deterministic reference state machine and tests for duplicate prevention and unlock conditions.

## Validation evidence
- Unit tests: 7 passed.
- Existing static map validator: PASS, 280 regions; all 12 required Inferno labels present; no static warnings.
- ZIP integrity: verified after packaging.
- No Galaxy Editor, runtime, pathing, or MPQ packaging validation was possible in this environment.

## Feature status
| Feature | Source work | Runtime status |
|---|---|---|
| Gate of No Return | Existing region retained; narrative text in state logic | Region only; no placed landmark or active interaction |
| Hidden Dante | New subregion, unique encounter text, idempotent state | Not connected to game triggers |
| Nine Lost Verses | Nine anchors, IDs, original texts, tested collection logic | Not connected to game triggers |
| Divine Comedy artifact | Anchor, text, all-nine unlock rule, duplicate protection in reference model | Not connected to game triggers |
| Three-Faced King | Arena anchor, encounter lifecycle and retry/victory state | No actual boss unit, combat behavior, or trigger integration |
| Nine-circle terrain transformation | No binary terrain changes | Not implemented |
| Survival preservation | Original terrain/object binary data preserved untouched | Runtime preservation untested |
| Packed `.SC2Map` | Not produced | Blocked by missing verified packer/editor |

## Rollback
Replace `Dantes_Inferno.SC2Map/Regions` with the Alpha 0.9 copy. Remove `systems/`, `tests/`, `design/`, `MILESTONE_1.0.md`, `TEST_REPORT.md`, and `CHANGELOG.md`. The original input archive remains the authoritative untouched backup.

## Next milestone
Alpha 1.1 must integrate the state contracts into the real map trigger framework and establish a reproducible map build. Then implement the first real playable slice: Gate/Dark Wood/Limbo with supported in-game assets and tested pathing. Do not proceed to full terrain conversion until the build pipeline and survival baseline are verified.

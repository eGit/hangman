# Source change ledger

Only one file inside the existing map source was modified: `Dantes_Inferno.SC2Map/Regions` (12 regions appended; existing 268 retained). All original terrain, texture, cliff, object-placement, MapInfo, and terrain-catalog files were copied without modification from Alpha 0.8 source. New standalone files are listed below.

## New files
- `systems/narrative_manifest.json`
- `systems/inferno_state.py`
- `tests/test_inferno_state.py`
- `design/NARRATIVE_AND_REGION_IMPLEMENTATION.md`
- `MILESTONE_1.0.md`
- `CHANGELOG.md`
- `README.md`
- `TEST_REPORT.md`
- `BASELINE_SOURCE_SHA256.csv`
- `SOURCE_CHANGES.md`

## Rollback
Restore `Dantes_Inferno.SC2Map/Regions` from the original supplied archive/Alpha 0.9 package to undo map-source changes. Remove the new files above to remove the narrative prototype. The original input archive was not modified.

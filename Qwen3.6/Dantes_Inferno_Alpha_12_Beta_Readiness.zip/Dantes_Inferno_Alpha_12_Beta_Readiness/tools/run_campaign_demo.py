#!/usr/bin/env python3
"""Run a deterministic end-to-end narrative campaign smoke test."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from systems.inferno_campaign import Campaign

campaign = Campaign()
print(campaign.run.discover_gate())
print(campaign.run.discover_dante())
for circle in range(1, 10):
    print(campaign.enter_circle(circle))
    print(campaign.collect_current_verse())
    print(campaign.clear_circle(circle))
print(campaign.collect_artifact())
print(campaign.run.start_boss())
print(campaign.run.resolve_boss(victory=True))
print("FINAL SUMMARY")
print(campaign.summary())
assert campaign.summary()["campaign_complete"]
assert campaign.summary()["verses_collected_count"] == 9
assert campaign.summary()["circles_cleared_count"] == 9

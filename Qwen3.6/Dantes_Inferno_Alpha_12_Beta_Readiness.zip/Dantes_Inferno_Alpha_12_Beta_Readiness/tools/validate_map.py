#!/usr/bin/env python3
"""Static integrity checks for the Dante's Inferno source-directory map package.

Run from this directory with: python tools/validate_map.py
No StarCraft II installation is required. This does not replace Galaxy Editor/game testing.
"""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MAP = ROOT / "Dantes_Inferno.SC2Map"
REGIONS = MAP / "Regions"
EXPECTED_INFERNO = {
    "Inferno_Gate_of_No_Return", "Inferno_Dark_Wood",
    "Inferno_I_Limbo", "Inferno_II_Tempest", "Inferno_III_Devouring_Pit",
    "Inferno_IV_Treasury_of_Ash", "Inferno_V_Black_River",
    "Inferno_VI_Burning_Necropolis", "Inferno_VII_River_of_Blood",
    "Inferno_VIII_Tenfold_Labyrinth", "Inferno_IX_Frozen_Heart",
    "Inferno_Three_Faced_King",
}
# Coordinates in the source's existing region definitions indicate a 256x256 map.
MAP_EXTENT = 256.0

def main():
    errors, warnings = [], []
    required = ["MapInfo", "Regions", "Objects", "t3Terrain.xml", "t3HeightMap",
                "t3TextureMasks", "Minimap.tga", "Base.SC2Data/GameData/Terrain/ZerusVolcanoes.xml"]
    for rel in required:
        if not (MAP / rel).is_file():
            errors.append(f"Missing required map asset: {rel}")

    if not REGIONS.is_file():
        errors.append("Regions XML is missing.")
    else:
        try:
            root = ET.parse(REGIONS).getroot()
        except ET.ParseError as exc:
            errors.append(f"Regions XML parse error: {exc}")
            root = None
        if root is not None:
            entries = root.findall("region")
            ids = [e.get("id") for e in entries]
            names = [e.find("name").get("value", "") if e.find("name") is not None else "" for e in entries]
            if len(ids) != len(set(ids)):
                errors.append("Duplicate region IDs detected.")
            if len(names) != len(set(names)):
                errors.append("Duplicate region names detected.")
            if any(not x for x in ids) or any(not x for x in names):
                errors.append("One or more regions have missing IDs or names.")
            missing = EXPECTED_INFERNO - set(names)
            if missing:
                errors.append("Missing Inferno region definitions: " + ", ".join(sorted(missing)))
            for entry in entries:
                shape = entry.find("shape")
                if shape is None:
                    errors.append(f"Region {entry.get('id')} has no shape.")
                    continue
                quad = shape.find("quad")
                if quad is not None:
                    try:
                        x1, y1, x2, y2 = [float(v) for v in quad.get("value", "").split(",")]
                        if x1 >= x2 or y1 >= y2:
                            errors.append(f"Region {entry.get('id')} has inverted/zero-area rectangle.")
                        if min(x1, y1) < 0 or max(x1, y1, x2, y2) > MAP_EXTENT:
                            warnings.append(f"Region {entry.get('id')} ({names[entries.index(entry)]}) extends outside inferred 0..{MAP_EXTENT:g} bounds.")
                    except (ValueError, TypeError):
                        errors.append(f"Region {entry.get('id')} has invalid rectangle coordinates.")
            print(f"Regions: {len(entries)} total; {len(EXPECTED_INFERNO)} required Inferno labels present.")
            print(f"Shapes: {sum(1 for e in entries if e.find('shape') is not None)}; rectangular: {sum(1 for e in entries if e.find('shape/quad') is not None)}.")

    # These are deliberately static checks only; binary map semantics need the editor.
    for w in warnings:
        print("WARN:", w)
    for e in errors:
        print("FAIL:", e)
    if errors:
        print(f"RESULT: FAIL ({len(errors)} error(s), {len(warnings)} warning(s))")
        return 1
    print(f"RESULT: PASS static checks ({len(warnings)} warning(s)).")
    print("NOT VERIFIED: Galaxy Editor import, pathing, region alignment, triggers, dependencies, multiplayer/gameplay.")
    return 0

if __name__ == "__main__":
    sys.exit(main())

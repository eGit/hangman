# Beta exit criteria — Alpha 1.2

Beta is not declared until every item below has evidence from the actual map/runtime.

- [ ] Original Kerrigan Survival triggers, dependencies, and wave logic preserved and regression-tested.
- [ ] Galaxy Editor opens the map source without blocking errors.
- [ ] Each logical region is reviewed against rendered terrain; coordinates corrected where needed.
- [ ] Gate and Dante interactions trigger once per run with player-facing feedback.
- [ ] All nine verses can be collected in the correct circle; duplicates do not increase progress.
- [ ] Circles unlock in order and cannot be cleared without the local verse.
- [ ] Divine Comedy artifact unlocks only after all nine circles and verses are complete.
- [ ] Three-Faced King encounter supports start, victory, failure, retry, and completion feedback.
- [ ] Minimap, object placements, pathing, collision, and transitions are checked in-game.
- [ ] A packed `.SC2Map` reopens in Galaxy Editor and launches a test game.
- [ ] Full playthrough and survival regression tests pass; multiplayer tested if supported.
- [ ] Release includes build manifest, SHA-256 hashes, test evidence, known issues, and rollback instructions.

## Alpha 1.2 progress

Completed in this package: deterministic event adapter, unique event-ID deduplication, strict event payload validation, campaign transition enforcement, trigger contract, and automated adapter tests.

Not completed: actual Galaxy trigger wiring, engine-level object interactions, map packing, editor validation, or in-game QA. These require the StarCraft II toolchain and must not be inferred from Python tests.

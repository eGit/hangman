"""Campaign orchestration layer for the Dante's Inferno source prototype.

This is an executable, deterministic reference implementation for campaign flow.
It is deliberately separate from StarCraft II's Galaxy runtime until the project's
real trigger/build pipeline is available. It does not alter KS2 survival-wave state.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
from pathlib import Path
from typing import Any

try:
    from .inferno_state import EncounterState, InfernoRun, VERSE_IDS
except ImportError:  # direct execution from systems/
    from inferno_state import EncounterState, InfernoRun, VERSE_IDS

CIRCLES = (
    ("Limbo", "VERSE_01"),
    ("The Tempest", "VERSE_02"),
    ("The Devouring Pit", "VERSE_03"),
    ("The Treasury of Ash", "VERSE_04"),
    ("The Black River", "VERSE_05"),
    ("The Burning Necropolis", "VERSE_06"),
    ("The River of Blood", "VERSE_07"),
    ("The Tenfold Labyrinth", "VERSE_08"),
    ("The Frozen Heart", "VERSE_09"),
)

@dataclass
class Campaign:
    """Per-match campaign state, including explicit circle gates and journal history."""
    run: InfernoRun = field(default_factory=InfernoRun)
    circles_cleared: set[int] = field(default_factory=set)
    active_circle: int = 0  # 0 is the Dark Wood prologue; 1..9 are the circles
    checkpoint_circle: int = 0
    journal: list[dict[str, Any]] = field(default_factory=list)

    def _record(self, event: str, **details: Any) -> None:
        self.journal.append({"sequence": len(self.journal) + 1, "event": event, **details})

    def enter_circle(self, circle: int) -> str:
        if not isinstance(circle, int) or isinstance(circle, bool) or not 1 <= circle <= 9:
            raise ValueError("circle must be an integer from 1 through 9")
        if circle > 1 and (circle - 1) not in self.circles_cleared:
            return f"{CIRCLES[circle - 1][0]} remains sealed; clear the previous circle first."
        if circle == 1 and not self.run.gate_discovered:
            return "The Gate of No Return must be discovered before entering Limbo."
        if circle in self.circles_cleared:
            self.active_circle = circle
            self._record("CIRCLE_REENTERED", circle=circle)
            return f"Returning to {CIRCLES[circle - 1][0]}."
        self.active_circle = circle
        self.checkpoint_circle = max(self.checkpoint_circle, circle)
        self._record("CIRCLE_ENTERED", circle=circle, name=CIRCLES[circle - 1][0])
        return f"Entered {CIRCLES[circle - 1][0]}. Find {CIRCLES[circle - 1][1]} and survive."

    def collect_current_verse(self) -> str:
        if not 1 <= self.active_circle <= 9:
            return "No Lost Verse can be recovered in the prologue."
        verse = CIRCLES[self.active_circle - 1][1]
        result = self.run.collect_verse(verse)
        self._record("VERSE_INTERACTION", circle=self.active_circle, verse=verse,
                     already_collected=(verse in self.run.collected_verses and
                                        sum(1 for e in self.run.story_events if e == f"COLLECTED:{verse}") > 1))
        return result

    def clear_circle(self, circle: int) -> str:
        if not isinstance(circle, int) or isinstance(circle, bool) or not 1 <= circle <= 9:
            raise ValueError("circle must be an integer from 1 through 9")
        if self.active_circle != circle:
            return "Only the currently active circle can be cleared."
        if CIRCLES[circle - 1][1] not in self.run.collected_verses:
            return f"Cannot clear {CIRCLES[circle - 1][0]} before recovering its Lost Verse."
        if circle in self.circles_cleared:
            return f"{CIRCLES[circle - 1][0]} is already cleared."
        self.circles_cleared.add(circle)
        self._record("CIRCLE_CLEARED", circle=circle, name=CIRCLES[circle - 1][0])
        if circle < 9:
            return f"{CIRCLES[circle - 1][0]} cleared. The way to {CIRCLES[circle][0]} is open."
        return "The Frozen Heart yields. All nine circles are cleared; the artifact may be claimed."

    def collect_artifact(self) -> str:
        if len(self.circles_cleared) != 9:
            return f"The Divine Comedy remains sealed. Circles cleared: {len(self.circles_cleared)}/9."
        result = self.run.collect_artifact()
        if self.run.artifact_collected:
            self._record("ARTIFACT_INTERACTION")
        return result

    def restart_after_failure(self) -> str:
        if self.run.boss_state != EncounterState.FAILED:
            return "A checkpoint restart is only available after a failed King encounter."
        self.active_circle = max(9, self.checkpoint_circle)
        self._record("CHECKPOINT_RESTARTED", circle=self.active_circle)
        return "Restarted at the Frozen Heart checkpoint; collected verses remain secured for this run."

    def summary(self) -> dict[str, Any]:
        return {
            "active_circle": self.active_circle,
            "checkpoint_circle": self.checkpoint_circle,
            "circles_cleared": sorted(self.circles_cleared),
            "circles_cleared_count": len(self.circles_cleared),
            "verses_collected_count": len(self.run.collected_verses),
            "artifact_collected": self.run.artifact_collected,
            "boss_state": self.run.boss_state.value,
            "campaign_complete": self.run.boss_state == EncounterState.VICTORY,
            "run": self.run.summary(),
            "journal": list(self.journal),
        }

    def save(self, path: str | Path) -> None:
        payload = {
            "schema_version": 1,
            "active_circle": self.active_circle,
            "checkpoint_circle": self.checkpoint_circle,
            "circles_cleared": sorted(self.circles_cleared),
            "run": {
                "gate_discovered": self.run.gate_discovered,
                "dante_discovered": self.run.dante_discovered,
                "collected_verses": sorted(self.run.collected_verses),
                "artifact_collected": self.run.artifact_collected,
                "boss_state": self.run.boss_state.value,
                "story_events": self.run.story_events,
            },
            "journal": self.journal,
        }
        Path(path).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "Campaign":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if data.get("schema_version") != 1:
            raise ValueError("Unsupported campaign save schema")
        run_data = data["run"]
        verses = set(run_data["collected_verses"])
        if not verses <= set(VERSE_IDS):
            raise ValueError("Save contains unknown verse identifiers")
        cleared = set(data["circles_cleared"])
        if not cleared <= set(range(1, 10)):
            raise ValueError("Save contains invalid circle numbers")
        if any(CIRCLES[i - 1][1] not in verses for i in cleared):
            raise ValueError("Save violates invariant: cleared circle must have its verse")
        if run_data["artifact_collected"] and (len(verses) != 9 or len(cleared) != 9):
            raise ValueError("Save violates invariant: artifact requires all verses and circles")
        active = data["active_circle"]
        checkpoint = data["checkpoint_circle"]
        if active not in range(10) or checkpoint not in range(10):
            raise ValueError("Save contains invalid active/checkpoint circle")
        run = InfernoRun(
            gate_discovered=bool(run_data["gate_discovered"]),
            dante_discovered=bool(run_data["dante_discovered"]),
            collected_verses=verses,
            artifact_collected=bool(run_data["artifact_collected"]),
            boss_state=EncounterState(run_data["boss_state"]),
            story_events=list(run_data["story_events"]),
        )
        if run.artifact_collected and run.boss_state == EncounterState.LOCKED:
            raise ValueError("Save violates invariant: artifact cannot leave boss locked")
        return cls(run=run, circles_cleared=cleared, active_circle=active,
                   checkpoint_circle=checkpoint, journal=list(data["journal"]))

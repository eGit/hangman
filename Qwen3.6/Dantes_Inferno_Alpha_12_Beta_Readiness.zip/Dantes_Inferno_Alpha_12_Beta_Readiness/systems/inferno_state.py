"""Reference state machine for Dante's Inferno narrative features.

This module is executable and unit-tested, but is NOT wired into StarCraft II's
compiled trigger system. It defines the expected gameplay behavior for porting
into the map's real trigger framework once that framework is available.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Set

VERSE_IDS = tuple(f"VERSE_{i:02d}" for i in range(1, 10))


class EncounterState(str, Enum):
    LOCKED = "locked"
    READY = "ready"
    ACTIVE = "active"
    VICTORY = "victory"
    FAILED = "failed"


@dataclass
class InfernoRun:
    """Per-run progression state. No persistence across matches is assumed."""
    gate_discovered: bool = False
    dante_discovered: bool = False
    collected_verses: Set[str] = field(default_factory=set)
    artifact_collected: bool = False
    boss_state: EncounterState = EncounterState.LOCKED
    story_events: list[str] = field(default_factory=list)

    def discover_gate(self) -> str:
        if self.gate_discovered:
            return "The Gate of No Return has already been witnessed."
        self.gate_discovered = True
        self.story_events.append("GATE_DISCOVERED")
        return "The gate stands open to the road below. There is no return to the world you knew."

    def discover_dante(self) -> str:
        if self.dante_discovered:
            return "The hooded witness has nothing more to say this time."
        self.dante_discovered = True
        self.story_events.append("DANTE_DISCOVERED")
        return ("A hooded witness waits where the path nearly disappears. "
                "You have not escaped the wood by finding a road. You have escaped it by choosing to walk.")

    def collect_verse(self, verse_id: str) -> str:
        if verse_id not in VERSE_IDS:
            raise ValueError(f"Unknown verse identifier: {verse_id}")
        if verse_id in self.collected_verses:
            return f"{verse_id} was already recovered; progress is unchanged."
        self.collected_verses.add(verse_id)
        self.story_events.append(f"COLLECTED:{verse_id}")
        if len(self.collected_verses) == 9:
            return f"{verse_id} recovered. All nine Lost Verses are assembled; the artifact can now be claimed."
        return f"{verse_id} recovered. Lost Verses: {len(self.collected_verses)}/9."

    def collect_artifact(self) -> str:
        if self.artifact_collected:
            return "The Divine Comedy artifact has already been claimed."
        if len(self.collected_verses) != 9:
            return f"The artifact remains sealed. Lost Verses required: 9; recovered: {len(self.collected_verses)}."
        self.artifact_collected = True
        self.boss_state = EncounterState.READY
        self.story_events.append("ARTIFACT_COLLECTED")
        return "Nine fragments settle into a single book. The Divine Comedy artifact is restored."

    def start_boss(self) -> str:
        if not self.artifact_collected:
            return "The Three-Faced King remains sealed behind the frozen heart."
        if self.boss_state == EncounterState.ACTIVE:
            return "The Three-Faced King encounter is already active."
        if self.boss_state == EncounterState.VICTORY:
            return "The Three-Faced King has already been defeated this run."
        if self.boss_state == EncounterState.FAILED:
            self.boss_state = EncounterState.READY
        self.boss_state = EncounterState.ACTIVE
        self.story_events.append("KING_ENCOUNTER_STARTED")
        return "The ice splits. Three faces turn toward the intruder."

    def resolve_boss(self, victory: bool) -> str:
        if self.boss_state != EncounterState.ACTIVE:
            raise RuntimeError("Cannot resolve the Three-Faced King unless the encounter is active.")
        self.boss_state = EncounterState.VICTORY if victory else EncounterState.FAILED
        self.story_events.append("KING_VICTORY" if victory else "KING_FAILED")
        if victory:
            return "The ice releases its last breath. The road ends, but the choice made along it remains."
        return "The frozen silence closes again. The descent may be attempted anew."

    @property
    def completion_percent(self) -> int:
        # Narrative objective completion only; does not alter survival wave progress.
        completed = int(self.gate_discovered) + int(self.dante_discovered)
        completed += len(self.collected_verses) + int(self.artifact_collected)
        completed += int(self.boss_state == EncounterState.VICTORY)
        return round(completed / 13 * 100)

    def summary(self) -> Dict[str, object]:
        return {
            "gate_discovered": self.gate_discovered,
            "dante_discovered": self.dante_discovered,
            "verses_collected": len(self.collected_verses),
            "verse_ids": sorted(self.collected_verses),
            "artifact_collected": self.artifact_collected,
            "boss_state": self.boss_state.value,
            "completion_percent": self.completion_percent,
            "story_events": list(self.story_events),
        }

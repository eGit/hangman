"""Engine-neutral event adapter for the Dante's Inferno campaign.

This module is the tested seam that Galaxy triggers should call through an equivalent
native bridge. It is NOT itself a StarCraft II Galaxy runtime and must not be mistaken
for a compiled map trigger. Event payloads are deliberately small and deterministic.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from .inferno_campaign import Campaign, CIRCLES
from .inferno_state import EncounterState

REGION_TO_CIRCLE = {f"Inferno_{i}_{name.replace(' ', '_')}": i for i, (name, _) in enumerate(CIRCLES, 1)}
VERSE_TO_REGION = {verse: f"Inferno_{verse}_{name.replace(' ', '_')}" for name, verse in CIRCLES}

@dataclass(frozen=True)
class RuntimeResult:
    accepted: bool
    code: str
    message: str
    campaign_complete: bool = False

class CampaignRuntime:
    """Dispatches trigger-like events into the authoritative campaign state machine."""
    def __init__(self, campaign: Campaign | None = None):
        self.campaign = campaign or Campaign()
        self._processed_ids: set[str] = set()

    def dispatch(self, event: dict[str, Any]) -> RuntimeResult:
        if not isinstance(event, dict):
            return RuntimeResult(False, "INVALID_EVENT", "Event must be an object.")
        event_id = event.get("event_id")
        event_type = event.get("type")
        if not isinstance(event_id, str) or not event_id.strip():
            return RuntimeResult(False, "MISSING_EVENT_ID", "A non-empty event_id is required.")
        if event_id in self._processed_ids:
            return RuntimeResult(False, "DUPLICATE_EVENT", "This event was already processed.")
        if not isinstance(event_type, str):
            return RuntimeResult(False, "MISSING_EVENT_TYPE", "A string event type is required.")
        c = self.campaign
        try:
            if event_type == "gate_discovered":
                message = c.run.discover_gate()
            elif event_type == "dante_discovered":
                if not c.run.gate_discovered:
                    return RuntimeResult(False, "GATE_REQUIRED", "Discover the Gate before Dante.")
                message = c.run.discover_dante()
            elif event_type == "enter_circle":
                circle = event.get("circle")
                message = c.enter_circle(circle)
                if "remains sealed" in message or "must be discovered" in message:
                    return RuntimeResult(False, "CIRCLE_LOCKED", message)
            elif event_type == "collect_verse":
                verse = event.get("verse_id")
                if verse not in {v for _, v in CIRCLES}:
                    return RuntimeResult(False, "UNKNOWN_VERSE", "Unknown verse identifier.")
                circle_index = next(i for i, (_, v) in enumerate(CIRCLES, 1) if v == verse)
                if c.active_circle != circle_index:
                    return RuntimeResult(False, "WRONG_CIRCLE", "A verse can only be collected in its active circle.")
                message = c.run.collect_verse(verse)
            elif event_type == "clear_circle":
                message = c.clear_circle(event.get("circle"))
                if "Cannot clear" in message or "Only the currently" in message or "already cleared" in message:
                    return RuntimeResult(False, "CLEAR_REJECTED", message)
            elif event_type == "collect_artifact":
                message = c.collect_artifact()
                if not c.run.artifact_collected:
                    return RuntimeResult(False, "ARTIFACT_LOCKED", message)
            elif event_type == "king_started":
                message = c.run.start_boss()
                if c.run.boss_state != EncounterState.ACTIVE:
                    return RuntimeResult(False, "KING_NOT_READY", message)
            elif event_type == "king_resolved":
                victory = event.get("victory")
                if not isinstance(victory, bool):
                    return RuntimeResult(False, "INVALID_OUTCOME", "victory must be a boolean.")
                message = c.run.resolve_boss(victory)
            elif event_type == "restart_after_failure":
                message = c.restart_after_failure()
                if "Restarted" not in message:
                    return RuntimeResult(False, "RESTART_REJECTED", message)
            else:
                return RuntimeResult(False, "UNKNOWN_EVENT", f"Unsupported event type: {event_type}")
        except (ValueError, RuntimeError, TypeError) as exc:
            return RuntimeResult(False, "INVALID_TRANSITION", str(exc))
        self._processed_ids.add(event_id)
        c._record("RUNTIME_EVENT", event_id=event_id, event_type=event_type)
        return RuntimeResult(True, "OK", message, c.run.boss_state == EncounterState.VICTORY)

# Dante’s Inferno — Alpha 1.2 Beta Readiness

This release advances the campaign source with a deterministic runtime-event adapter and explicit contract for porting events into Galaxy triggers. Existing map source and terrain binaries are preserved.

## Verify

From this directory:

```bash
python -m unittest discover -s tests -v
python tools/validate_map.py
python tools/run_campaign_demo.py
```

## What changed

- `systems/inferno_runtime.py`: trigger-like event dispatch, stable event IDs, duplicate suppression, typed payload checks, gated progression and result codes.
- `tests/test_inferno_runtime.py`: end-to-end adapter tests for the gate, verses, circle progression, artifact, boss victory/failure, and retry.
- `integration/GALAXY_TRIGGER_CONTRACT.json`: explicit contract for wiring the same transitions into Galaxy triggers.
- `BETA_EXIT_CRITERIA.md`: evidence-based exit gates.

## Honesty about runtime status

This remains a source-directory package. The Python adapter is not executable by StarCraft II and does not prove the map has working in-game triggers. Actual Galaxy trigger integration, region alignment, object placement, map packing, editor launch, and in-game regression remain open Beta blockers. No terrain binary or survival-wave logic was rewritten in this release.

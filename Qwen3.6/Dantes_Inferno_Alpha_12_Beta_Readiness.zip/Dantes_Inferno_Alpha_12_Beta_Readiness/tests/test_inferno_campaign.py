import json
import tempfile
import unittest
from pathlib import Path
from systems.inferno_campaign import Campaign, CIRCLES
from systems.inferno_state import EncounterState

class CampaignTests(unittest.TestCase):
    def setUp(self): self.c = Campaign()

    def test_circle_gates_enforced(self):
        self.assertIn("Gate", self.c.enter_circle(1))
        self.c.run.discover_gate()
        self.assertIn("previous circle", self.c.enter_circle(2))

    def test_cannot_clear_without_verse(self):
        self.c.run.discover_gate(); self.c.enter_circle(1)
        self.assertIn("before recovering", self.c.clear_circle(1))

    def test_sequential_full_campaign(self):
        self.c.run.discover_gate()
        for circle in range(1, 10):
            self.c.enter_circle(circle)
            self.c.collect_current_verse()
            self.assertIn("cleared", self.c.clear_circle(circle).lower())
        self.assertEqual(len(self.c.run.collected_verses), 9)
        self.assertTrue(self.c.collect_artifact())
        self.assertTrue(self.c.run.artifact_collected)
        self.assertEqual(len(self.c.circles_cleared), 9)

    def test_wrong_active_circle_cannot_clear(self):
        self.c.run.discover_gate(); self.c.enter_circle(1)
        self.assertIn("currently active", self.c.clear_circle(2))

    def test_checkpoint_and_retry(self):
        self.c.run.discover_gate()
        for i in range(1,10):
            self.c.enter_circle(i); self.c.collect_current_verse(); self.c.clear_circle(i)
        self.c.collect_artifact(); self.c.run.start_boss(); self.c.run.resolve_boss(False)
        self.assertIn("Restarted", self.c.restart_after_failure())
        self.assertEqual(self.c.active_circle, 9)
        self.assertEqual(len(self.c.run.collected_verses), 9)

    def test_save_load_round_trip(self):
        self.c.run.discover_gate(); self.c.enter_circle(1); self.c.collect_current_verse()
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "save.json"; self.c.save(p); loaded = Campaign.load(p)
        self.assertEqual(loaded.summary(), self.c.summary())

    def test_corrupt_save_invariant_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "save.json"
            p.write_text(json.dumps({"schema_version":1,"active_circle":1,"checkpoint_circle":1,
              "circles_cleared":[1],"run":{"gate_discovered":True,"dante_discovered":False,
              "collected_verses":[],"artifact_collected":False,"boss_state":"locked","story_events":[]},"journal":[]}))
            with self.assertRaises(ValueError): Campaign.load(p)

    def test_circle_manifest_has_nine_unique_verses(self):
        self.assertEqual(len(CIRCLES), 9)
        self.assertEqual(len({verse for _, verse in CIRCLES}), 9)

if __name__ == '__main__': unittest.main()

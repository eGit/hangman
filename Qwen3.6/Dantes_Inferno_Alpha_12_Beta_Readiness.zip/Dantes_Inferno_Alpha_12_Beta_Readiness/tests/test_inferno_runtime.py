import unittest
from systems.inferno_runtime import CampaignRuntime

class RuntimeAdapterTests(unittest.TestCase):
    def setUp(self): self.rt = CampaignRuntime()
    def send(self, eid, typ, **kw): return self.rt.dispatch({"event_id": eid, "type": typ, **kw})
    def complete_to_artifact(self):
        self.send("gate", "gate_discovered")
        for i in range(1, 10):
            self.assertTrue(self.send(f"enter{i}", "enter_circle", circle=i).accepted)
            self.assertTrue(self.send(f"verse{i}", "collect_verse", verse_id=f"VERSE_{i:02d}").accepted)
            self.assertTrue(self.send(f"clear{i}", "clear_circle", circle=i).accepted)
        self.assertTrue(self.send("artifact", "collect_artifact").accepted)
    def test_gate_precedes_dante(self):
        self.assertEqual(self.send("d1", "dante_discovered").code, "GATE_REQUIRED")
        self.assertTrue(self.send("g1", "gate_discovered").accepted)
        self.assertTrue(self.send("d2", "dante_discovered").accepted)
    def test_event_id_deduplication(self):
        self.assertTrue(self.send("g", "gate_discovered").accepted)
        self.assertEqual(self.send("g", "gate_discovered").code, "DUPLICATE_EVENT")
    def test_verse_requires_active_circle(self):
        self.assertEqual(self.send("v", "collect_verse", verse_id="VERSE_01").code, "WRONG_CIRCLE")
    def test_unknown_event_rejected_without_consuming_id(self):
        self.assertEqual(self.send("x", "mystery").code, "UNKNOWN_EVENT")
        self.assertTrue(self.send("x", "gate_discovered").accepted)
    def test_full_campaign_victory(self):
        self.complete_to_artifact()
        self.assertTrue(self.send("king", "king_started").accepted)
        result = self.send("win", "king_resolved", victory=True)
        self.assertTrue(result.accepted); self.assertTrue(result.campaign_complete)
    def test_artifact_locked_until_all_circles_cleared(self):
        self.send("g", "gate_discovered")
        self.assertEqual(self.send("a", "collect_artifact").code, "ARTIFACT_LOCKED")
    def test_invalid_outcome_rejected(self):
        self.complete_to_artifact(); self.send("king", "king_started")
        self.assertEqual(self.send("resolve", "king_resolved", victory="yes").code, "INVALID_OUTCOME")
    def test_failure_retry_then_victory(self):
        self.complete_to_artifact(); self.send("king1", "king_started")
        self.assertTrue(self.send("fail", "king_resolved", victory=False).accepted)
        self.assertTrue(self.send("restart", "restart_after_failure").accepted)
        self.assertTrue(self.send("king2", "king_started").accepted)
        self.assertTrue(self.send("win", "king_resolved", victory=True).campaign_complete)

if __name__ == '__main__': unittest.main()

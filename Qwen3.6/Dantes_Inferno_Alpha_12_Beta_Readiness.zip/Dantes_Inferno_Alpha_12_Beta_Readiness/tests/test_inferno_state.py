import unittest
from systems.inferno_state import InfernoRun, EncounterState, VERSE_IDS


class InfernoStateTests(unittest.TestCase):
    def test_gate_and_dante_are_idempotent(self):
        run = InfernoRun()
        first = run.discover_gate()
        second = run.discover_gate()
        self.assertNotEqual(first, second)
        self.assertEqual(sum(e == "GATE_DISCOVERED" for e in run.story_events), 1)
        run.discover_dante()
        run.discover_dante()
        self.assertEqual(sum(e == "DANTE_DISCOVERED" for e in run.story_events), 1)

    def test_all_nine_verses_unique_and_duplicates_do_not_increment(self):
        run = InfernoRun()
        for verse in VERSE_IDS:
            run.collect_verse(verse)
        self.assertEqual(len(run.collected_verses), 9)
        run.collect_verse("VERSE_01")
        self.assertEqual(len(run.collected_verses), 9)
        with self.assertRaises(ValueError):
            run.collect_verse("VERSE_10")

    def test_artifact_requires_all_nine_verses(self):
        run = InfernoRun()
        self.assertIn("remains sealed", run.collect_artifact())
        for verse in VERSE_IDS[:-1]:
            run.collect_verse(verse)
        self.assertFalse(run.artifact_collected)
        run.collect_verse(VERSE_IDS[-1])
        run.collect_artifact()
        self.assertTrue(run.artifact_collected)
        self.assertEqual(run.boss_state, EncounterState.READY)
        self.assertIn("already been claimed", run.collect_artifact())

    def test_boss_unlock_start_victory(self):
        run = InfernoRun()
        self.assertIn("remains sealed", run.start_boss())
        for verse in VERSE_IDS:
            run.collect_verse(verse)
        run.collect_artifact()
        self.assertIn("ice splits", run.start_boss())
        self.assertEqual(run.boss_state, EncounterState.ACTIVE)
        self.assertIn("already active", run.start_boss())
        self.assertIn("road ends", run.resolve_boss(True))
        self.assertEqual(run.boss_state, EncounterState.VICTORY)
        self.assertIn("already been defeated", run.start_boss())

    def test_boss_failure_can_retry(self):
        run = InfernoRun()
        for verse in VERSE_IDS:
            run.collect_verse(verse)
        run.collect_artifact()
        run.start_boss()
        self.assertIn("attempted anew", run.resolve_boss(False))
        self.assertEqual(run.boss_state, EncounterState.FAILED)
        run.start_boss()
        self.assertEqual(run.boss_state, EncounterState.ACTIVE)

    def test_cannot_resolve_inactive_boss(self):
        with self.assertRaises(RuntimeError):
            InfernoRun().resolve_boss(True)

    def test_narrative_completion_does_not_claim_survival_progression(self):
        run = InfernoRun()
        self.assertEqual(run.completion_percent, 0)
        for verse in VERSE_IDS:
            run.collect_verse(verse)
        self.assertEqual(run.completion_percent, round(9 / 13 * 100))
        self.assertNotIn("wave", run.summary())


if __name__ == "__main__":
    unittest.main(verbosity=2)
